<?php namespace App\Models;

use CodeIgniter\Model;
use App\Models\ModelBZTime;

//use CodeIgniter\HTTP\RequestInterface;

class ModelProject extends Model
{

	public $t_customer;
	public $t_template;
	public $session;
	public $date;

	public function __construct()
	{
		$this->db_config = \Config\Database::connect('default', false);
		$this->t_customer = $this->db_config->table('t_customer');

		$this->ModelBZTime = new ModelBZTime();

		$this->session = \Config\Services::session();
		$this->session = $this->session->get();
		$this->date = date("Y-m-d h:i:s");
	}

	public function get()
	{	

		$customer = $this->db_config
			->table('t_customer')
			//->where('t_customer.user_id', $this->session['uid'])
			// ->where('t_customer.customer_name !=', $MENU_ITEMS)
			->select('
				t_customer.customer_id,
				t_customer.customer_name,
			')
			->get()
			->getResult();

		$template = $this->db_config
			->table('t_customer')
			//->where('t_customer.user_id', $this->session['uid'])
			->where('t_template.is_delete', 0)
			->select('
				t_template.id,
				t_template.customer_id,
				t_template.template_id,
				t_template.template_name,
				t_template.update_date
			')
			->join('t_template', 't_template.customer_id = t_customer.customer_id')
			->get()
			->getResult();

		foreach($customer as $val){
            $customer_id = $val->customer_id;
            if(!$val->template){
            	$val->template = [];
            }
            $num = 0;
            foreach($template as $templateVal){
            	$num++;
            	$template_customer_id = $templateVal->customer_id;
            	if($customer_id === $template_customer_id){
            		//$templateVal->package = json_decode($templateVal->package);
            		array_push($val->template, $templateVal);
            	}

            	if(count($template) === $num){
            		array_push($val->template, array(
            			'customer_id' => $val->customer_id,
            			'template_id' => $val->customer_id,
            			'template_name' => 'SET CUSTOMER'
            		));
            	}
            }
        }
		//$customer = $this->ModelBZTime->customer();

        echo json_encode($customer);
	}

	public function getCustomerID($customer_id)
	{
		$customer = $this->db_config
			->table('t_customer')
			->where('t_customer.customer_id', $customer_id)
			//->where('t_customer.user_id', $this->session['uid'])
			//->where('t_template.user_id', $this->session['uid'])
			->select('
				t_customer.customer_id,
				t_customer.customer_name,
				t_customer.update_date,
				t_customer.package,
				t_countries.country_code,
				t_countries.measure_type
			')
			->join('t_countries', 't_countries.country_code = t_customer.country_code')
			->get()
			->getResult();

		foreach($customer as $customerVal){
			$customerVal->package = json_decode($customerVal->package);
		}

		echo json_encode($customer);
	}
	
	public function getTemplateID($template_id)
	{
		$customer = $this->db_config
			->table('t_customer')
			->where('t_customer.customer_id', $template_id)
			->countAllResults();

		if($customer){

			$template = $this->db_config
				->table('t_customer')
				->where('t_customer.customer_id', $template_id)
				//->where('t_customer.user_id', $this->session['uid'])
				//->where('t_template.user_id', $this->session['uid'])
				->select('
					t_customer.customer_id,
					t_customer.customer_name,
					t_customer.update_date,
					t_customer.package,
					t_countries.country_code,
					t_countries.measure_type
				')
				->join('t_countries', 't_countries.country_code = t_customer.country_code')
				->get()
				->getResult();

			foreach($template as $templateVal){
				$templateVal->template_id = $templateVal->customer_id;
				$templateVal->template_name = "SET";
				$templateVal->package = json_decode($templateVal->package);
			}

			echo json_encode($template);

		}else{	
			$template = $this->db_config
				->table('t_template')
				->where('t_template.template_id', $template_id)
				//->where('t_customer.user_id', $this->session['uid'])
				//->where('t_template.user_id', $this->session['uid'])
				->select('
					t_customer.package as customer_package,
					t_template.customer_id,
					t_template.template_id,
					t_template.template_name,
					t_template.update_date,
					t_template.package,
					t_template.language,
					t_countries.country_code,
					t_countries.measure_type
				')
				->join('t_customer', 't_customer.customer_id = t_template.customer_id')
				->join('t_countries', 't_countries.country_code = t_customer.country_code')
				->get()
				->getResult();

			foreach($template as $templateVal){
				$templateVal->customer_package = json_decode($templateVal->customer_package);
				$templateVal->package = json_decode($templateVal->package);
			}

			echo json_encode($template);
		}
	}

	public function insert_customer($customer)
	{

		$result = $this->db_config
			->table('t_customer')
			->where('customer_name', $customer)
			->countAllResults();

		if($result === 0){

			$time_customer = $this->ModelBZTime->customer($customer);
			$time = [];
			foreach($time_customer as $val){
				$time['customer_name'] = $val->namecustomer;
				$time['customer_code'] = $val->customer_code;
				$time['country_code'] = $val->country_code;
				$time['address'] = $val->address5;
			}

			$data = [
        		'id' => uniqid(),
				'customer_id' => hexdec(uniqid()),
				'customer_name' => $time['customer_name'],
				'customer_code' => $time['customer_code'],
				'country_code' => $time['country_code'],
				'address' => $time['address'],
				'user_id' => $this->session['uid'],
				'update_date' => $this->date,
				'create_date' => $this->date
			];

			$country = $this->db_config
				->table('t_countries')
				->where('country_code', $time['country_code'])
				->countAllResults();

			if($country === 0){

				$countryData = [
					'country_id' => uniqid(),
					'country_code' => $time['country_code'],
					'country_name' => $time['address'],
					'country_text' => $time['country_code'],
					'measure_type' => ($time['country_code'] != 'US' || $time['country_code'] != 'UK') ? 'metric' : 'imperial'
				];

				$countries = $this->db_config
					->table('t_countries')
					->insert($countryData);
			}

			$customer = $this->t_customer
	    		->insert($data);

	    	if($customer){
	    		$output = [
	    			'customer_id' => $data['customer_id'],
	    			'customer_name' => $data['customer_name'],
	    		];

	    		return $output;
	    	}
		}else{
			return ['error' => 2];
		}
	}

	public function insert_template($customer, $template)
	{	

		$checkCustomer = $this->db_config
			->table('t_customer')
			->where('customer_id', $customer)
			->countAllResults();

		$checkTemplate = $this->db_config
			->table('t_template')
			->where('customer_id', $customer)
			->where('template_name', $template)
			->where('is_delete', 0)
			->countAllResults();

        if($checkCustomer > 0 && $checkTemplate === 0){
        	$resultCustomer = $this->db_config
				->table('t_customer')
				->where('customer_id', $customer)
				->select('package')
				->get()
				->getResult();

			$package = '';

			if($resultCustomer[0]->package != ''){
				$package = $resultCustomer[0]->package;
			}

        	$data = [
        		'id' => uniqid(),
				'customer_id' => $customer,
				'template_id' => hexdec(uniqid()),
				'template_name' => $template,
				'user_id' => $this->session['uid'],
				'update_date' => $this->date,
				'create_date' => $this->date,
				'package' => $package
			];

        	$template = $this->db_config
	    		->table('t_template')
	    		->insert($data);

	    	if($template){
	    		$output = [
	    			'customer' => $data['customer_id'],
	    			'template' => $data['template_id'],
	    		];
	    		return $output;
	    	}
        }else{
        	return ['error' => 2];
        }

	}

	public function clone_template($template)
	{
		$recent = get_cookie('recent');
		$recent = explode('.', $recent);

		$checkTemplate = $this->db_config
			->table('t_template')
			->where('customer_id', $recent[0])
			->where('template_name', $template)
			->countAllResults();

		if($checkTemplate === 0){
			$Template = $this->db_config
				->table('t_template')
				->where('template_id', $recent[1])
				->select('package')
				->get()
				->getResult();

			$data = [
        		'id' => uniqid(),
				'customer_id' => $recent[0],
				'template_id' => hexdec(uniqid()),
				'template_name' => $template,
				'user_id' => $this->session['uid'],
				'update_date' => $this->date,
				'create_date' => $this->date,
				'package' => $Template[0]->package
			];

			$insert = $this->db_config
	    		->table('t_template')
	    		->insert($data);

	    	if($insert){
	    		$output = [
	    			'customer' => $data['customer_id'],
	    			'template' => $data['template_id'],
	    		];
	    		return $output;
	    	}

		}else{
        	return ['error' => 2];
        }
	}

	public function upload($customer_id, $template_id, $language, $data, $files)
	{	

	    $data = [
	    	'language' => $language,
	    	'package' => json_encode($data),
	    	'update_date' => $this->date
	    ];

	    if($customer_id === $template_id){
	    	$template = $this->db_config
		    	->table('t_customer')
		    	->where('customer_id', $customer_id)
		    	->update($data);
	    }else{

		    $template = $this->db_config
		    	->table('t_template')
		    	->where('template_id', $template_id)
		    	->update($data);
		}

		if($template){
			
			$info = pathinfo($files['file']['name']);
			$ext = $info['extension']; // get the extension of the file
			$newname = $customer_id.'.'.$template_id.'.'.$ext;
			$target = 'package/'.$newname;
			move_uploaded_file( $_FILES['file']['tmp_name'], $target);

		    $output = [
		    	'status' => 200,
		    	'message' => 'upload successfuly'
		    ];
		    return $output;
		}
	}

	public function upload_image($files){

		$info = pathinfo($files['file']['name']);
		$ext = $info['extension']; // get the extension of the file
		$newname = hexdec(uniqid()).'.'.$ext;
		$target = 'assets/picture/'.$newname;
		move_uploaded_file( $_FILES['file']['tmp_name'], $target);

		$output = [
			'url' => $target,
		   	'status' => 200,
		    'message' => 'upload successfuly'
		];
		return $output;
	}

	public function style($type){
		$template = $this->db_config
	    	->table('t_template')
	    	->where('type', $type)
	    	->where('is_delete', 0)
	    	->select('id, type, style, template_name, template_id')
	    	->get()
			->getResult();

		if($template){
			$style = []; $array = [];
			foreach($template as $val){
				$st = true;
				foreach($style as $name){
					if($name === $val->style){
						$st = false;
					}
				}
				if($st){
					array_push($style, $val->style);
				}
			}
			foreach($template as $val){
				$i = 0;
				foreach($style as $name){
					if($name === $val->style){
						if(!$array[$i]){
							$array[$i] = [];
							$array[$i]['type'] = ($type==='S' ? 'standard' : 'custom');
							$array[$i]['style'] = $name;
							$array[$i]['name'] = $name.' '.'styles';
							$array[$i]['group'] = [];
						}
						array_push($array[$i]['group'], array(
							'template_id' => $val->template_id,
							'template_name' => $val->template_name
						));
					}
					$i++;
				}
				
			}
			return $array;
		}
		return false;
	}

	public function country(){
		$country = $this->db_config
	    	->table('t_countries')
	    	->select('country_code, country_text')
	    	->get()
			->getResult();

		if($country){
			return $country;
		}

		return false;
	}

	public function textStyle(){
		$style = $this->db_config
	    	->table('t_text_style')
	    	->select('customer, style, font, formate, font_size as font-size, opacity, color, bound, bold, italic, underline')
	    	->get()
			->getResult();

		if($style){
			return $style;
		}

		return false;
	}
}