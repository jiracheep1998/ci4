<?php namespace App\Models;

use CodeIgniter\Model;

//use CodeIgniter\HTTP\RequestInterface;

class ModelBZTime extends Model
{

	public $session;
	public $date;

	public function __construct()
	{
		$this->db_time = \Config\Database::connect('baezenic_time', false);

		$this->session = \Config\Services::session();
		$this->session = $this->session->get();
		$this->date = date("Y-m-d h:i:s");
	}

	public function customer($customer_id)
	{
		if($customer_id){
			$customer = $this->db_time
				->table('t_customer')
				->where('customer_code', $customer_id)
				->select('
					customer_code,
					namecustomer,
					country_code,
					address5
				')
				->get()
				->getResult();
		}else{
			$customer = $this->db_time
				->table('t_customer')
				->select('
					customer_code,
					namecustomer
				')
				->get()
				->getResult();
		}

		return $customer;
	}
}