<?php namespace App\Models;

use CodeIgniter\Model;

//use CodeIgniter\HTTP\RequestInterface;

class ModelAdmin extends Model
{

	public $t_customer;
	public $t_template;

	public function __construct()
	{
		$this->db_config = \Config\Database::connect('default', false);
		$this->t_customer = $this->db_config->table('t_customer');

		$this->session = \Config\Services::session();
	}


	//--------------------------------CUSTOMER-----------------------------------------//

	public function customer()
	{
		$customer = $this->db_config
			->table('t_customer')
			->select('customer_id, customer_name, user_id, create_date, status, package, is_delete')
			->get()
			->getResult();

		return $customer;
	}

	public function customer_edit($customer_id)
	{

		$customer = $this->db_config
			->table('t_customer')
			->where('customer_id', $customer_id)
			->select('customer_id, customer_name, user_id, create_date, status, is_delete')
			->get()
			->getResult();

		return $customer;
	}

	public function customer_editor_get_data($customer_id){
		$customer = $this->db_config
			->table('t_customer')
			->where('customer_id', $customer_id)
			->select('package')
			->get()
			->getResult();

		return $customer;
	}

	public function customer_editor_get_svg($customer_id){
		$customer = $this->db_config
			->table('t_customer')
			->where('customer_id', $customer_id)
			->select('customer_id')
			->get()
			->getResult();

		$filename = $customer[0]->customer_id.'.'.$customer[0]->customer_id.'.svg';
		$data = base64_decode(file_get_contents(base_url()."/package/".$filename));

		return $data;
	}


	public function customer_editor($type, $customer_id)
	{
		$customer = $this->db_config
			->table('t_customer')
			->where('customer_id', $customer_id)
			->select('customer_id, customer_name, package')
			->get()
			->getResult();

		$customer[0]->type = $type;
		return $customer;
	}

	public function customer_method_editor($type, $customer_id, $form){
		if($type === 'svg'){
			$info = pathinfo($_FILES['file']['name']);
			$ext = $info['extension']; // get the extension of the file
			$newname = $customer_id.'.'.$customer_id.'.'.$ext;
			$target = 'package/'.$newname;
			move_uploaded_file($_FILES['file']['tmp_name'], $target);

		    return [
				'update' => true,
				'message' => 'upload successfuly'
			];

		}else{
			$data = [
				'package' => json_encode(json_decode($form['package']), JSON_NUMERIC_CHECK)
			];

			$customer = $this->db_config
				->table('t_customer')
				->where('customer_id', $customer_id)
				->update($data);

			if($customer){
				return [
					'update' => true,
					'message' => 'Save editor successfully!'
				];
			}

			return [
				'error' => true,
				'update' => false,
				'message' => 'Save editor fail!'
			];
		}
	}

	public function customer_method_edit($customer_id, $form)
	{
		$data = [
			'customer_name' => $form['customer_name'],
			'status' => $form['status']
		];

		$template = $this->db_config
			->table('t_customer')
			->where('customer_id', $customer_id)
			->update($data);

		if($template){
			return [
				'update' => true,
				'message' => 'Edit customer successfully!'
			];
		}

		return [
			'error' => true,
			'update' => false,
			'message' => 'Edit customer fail!'
		];
	}

	public function customer_method_delete($customer_id)
	{
		$get = $this->db_config
			->table('t_customer')
			->where('customer_id', $customer_id)
			->select('is_delete')
			->get()
			->getResult();

		$state = ($get[0]->is_delete) ? 0 : 1;

		$data = [
			'is_delete' => $state
		];

		$template = $this->db_config
			->table('t_customer')
			->where('customer_id', $customer_id)
			->update($data);

		if($template){
			return [
				'update' => true,
				'message' => ($state) ? 'Delete customer successfully!' : 'Restore customer successfully!'
			];
		}

		return [
			'error' => true,
			'update' => false,
			'message' => ($state) ? 'Delete customer fail!' : 'Restore customer fail!'
		];
	}


	//--------------------------------TEMPLATE-----------------------------------------//

	public function template_project()
	{
		$customer = $this->db_config
			->table('t_customer')
			//->where('t_customer.user_id', $this->session['uid'])
			// ->where('t_customer.customer_name !=', $MENU_ITEMS)
			->select('
				t_customer.customer_id,
				t_customer.customer_name,
			')
			->get()
			->getResult();

		$template = $this->db_config
			->table('t_customer')
			//->where('t_customer.user_id', $this->session['uid'])
			->where('t_template.is_delete', 0)
			->select('
				t_template.id,
				t_template.customer_id,
				t_template.template_id,
				t_template.template_name,
				t_template.update_date
			')
			->join('t_template', 't_template.customer_id = t_customer.customer_id')
			->get()
			->getResult();

		foreach($customer as $val){
            $customer_id = $val->customer_id;
            if(!$val->template){
            	$val->template = [];
            }
            $num = 0;
            foreach($template as $templateVal){
            	$num++;
            	$template_customer_id = $templateVal->customer_id;
            	if($customer_id === $template_customer_id){
            		//$templateVal->package = json_decode($templateVal->package);
            		array_push($val->template, $templateVal);
            	}

            	if(count($template) === $num){
            		array_push($val->template, array(
            			'customer_id' => $val->customer_id,
            			'template_id' => $val->customer_id,
            			'template_name' => 'SET CUSTOMER'
            		));
            	}
            }
        }
		//$customer = $this->ModelBZTime->customer();

        return $customer;
	}

	public function template($type)
	{
		if($type == 'general'){
			$type = '';
		}else{
			$type = ($type == 'standard') ? 'S' : 'C';
		}
		
		$template = $this->db_config
			->table('t_customer')
			->where('t_template.type', $type)
			->where('t_template.is_delete', 0)
			->where('t_customer.is_delete', 0)
			->select('
				t_customer.customer_id,
				t_customer.customer_name,
				t_template.template_id,
				t_template.template_name,
				t_template.type,
				t_template.style,
				t_template.user_id,
				t_template.create_date,
				t_template.status,
				t_template.is_delete,
				t_template.package
			')
			->join('t_template', 't_template.customer_id = t_customer.customer_id')
			->get()
			->getResult();

		$template['set'] = $this->template_project();
		return $template;
	}

	public function template_edit($template_id)
	{

		$template = $this->db_config
			->table('t_template')
			->where('template_id', $template_id)
			->select('customer_id, template_id, template_name, type, style, user_id, status, is_delete')
			->get()
			->getResult();

		return $template;
	}

	public function template_method_edit($template_id, $form)
	{
		$data = [
			'template_name' => $form['template_name'],
			'type' => $form['type'],
			'style' => $form['style'],
			'status' => $form['status']
		];

		$template = $this->db_config
			->table('t_template')
			->where('template_id', $template_id)
			->update($data);

		if($template){
			return [
				'update' => true,
				'message' => 'Edit template successfully!'
			];
		}

		return [
			'error' => true,
			'update' => false,
			'message' => 'Edit member fail!'
		];
	}

	public function template_editor($type, $template_id)
	{
		$template = $this->db_config
			->table('t_template')
			->where('template_id', $template_id)
			->select('template_id, template_name, package')
			->get()
			->getResult();

		$template[0]->type = $type;
		return $template;
	}

	public function template_editor_get_svg($template_id){
		$template = $this->db_config
			->table('t_template')
			->where('template_id', $template_id)
			->select('customer_id, template_id')
			->get()
			->getResult();

		$filename = $template[0]->customer_id.'.'.$template[0]->template_id.'.svg';
		$data = base64_decode(file_get_contents(base_url()."/package/".$filename));

		return $data;
	}

	public function template_editor_get_data($template_id){
		$template = $this->db_config
			->table('t_template')
			->where('template_id', $template_id)
			->select('package')
			->get()
			->getResult();

		return $template;
	}

	public function template_method_editor($type, $template_id, $form){
		if($type === 'svg'){

			$get = $this->db_config
			->table('t_template')
			->where('template_id', $template_id)
			->select('customer_id')
			->get()
			->getResult();

			$info = pathinfo($_FILES['file']['name']);
			$ext = $info['extension']; // get the extension of the file
			$newname = $get[0]->customer_id.'.'.$template_id.'.'.$ext;
			$target = 'package/'.$newname;
			move_uploaded_file($_FILES['file']['tmp_name'], $target);

		    return [
				'update' => true,
				'message' => 'upload successfuly'
			];

		}else{

			$data = [
				'package' => json_encode($form['package'], JSON_NUMERIC_CHECK)
			];

			$template = $this->db_config
				->table('t_template')
				->where('template_id', $template_id)
				->update($data);

			if($template){
				return [
					'update' => true,
					'message' => 'Save editor successfully!'
				];
			}

			return [
				'error' => true,
				'update' => false,
				'message' => 'Save editor fail!'
			];
		}
	}

	public function template_method_delete($template_id)
	{

		$get = $this->db_config
			->table('t_template')
			->where('template_id', $template_id)
			->select('is_delete')
			->get()
			->getResult();

		$state = ($get[0]->is_delete) ? 0 : 1;

		$data = [
			'is_delete' => $state
		];

		$template = $this->db_config
			->table('t_template')
			->where('template_id', $template_id)
			->update($data);

		if($template){
			return [
				'update' => true,
				'message' => ($state) ? 'Delete template successfully!' : 'Restore template successfully!'
			];
		}

		return [
			'error' => true,
			'update' => false,
			'message' => ($state) ? 'Delete template fail!' : 'Restore template fail!'
		];
	}


	//--------------------------------MEMBER-----------------------------------------//


	public function member_customer()
	{
		$member_customer = $this->db_config
			->table('t_customer_account')
			->select('name, user_id, username, email, create_date, status, is_delete')
			->get()
			->getResult();

		return $member_customer;
	}

	public function member_customer_method_edit($user_id, $form)
	{
		$data = [
			'name' => $form['name'],
			'email' => $form['email'],
			'status' => $form['status'],
		];

		$customer = $this->db_config
			->table('t_customer_account')
			->where('user_id', $user_id)
			->update($data);

		if($customer){
			return [
				'update' => true,
				'message' => 'Edit member successfully!'
			];
		}

		return [
			'error' => true,
			'update' => false,
			'message' => 'Edit member fail!'
		];
	}

	public function member_customer_method_delete($user_id)
	{
		$get = $this->db_config
			->table('t_customer_account')
			->where('user_id', $user_id)
			->select('is_delete')
			->get()
			->getResult();

		$state = ($get[0]->is_delete) ? 0 : 1;

		$data = [
			'is_delete' => $state
		];

		$template = $this->db_config
			->table('t_customer_account')
			->where('user_id', $user_id)
			->update($data);

		if($template){
			return [
				'update' => true,
				'message' => ($state) ? 'Delete member successfully!' : 'Restore member successfully!'
			];
		}

		return [
			'error' => true,
			'update' => false,
			'message' => ($state) ? 'Delete member fail!' : 'Restore member fail!'
		];
	}

	public function member_operator()
	{
		$member_operator = $this->db_config
			->table('t_operator_account')
			->select('name, user_id, username, email, create_date, status, is_delete')
			->get()
			->getResult();

		return $member_operator;
	}

	public function member_operator_method_edit($user_id, $form)
	{
		$data = [
			'name' => $form['name'],
			'email' => $form['email'],
			'status' => $form['status'],
		];

		$operator = $this->db_config
			->table('t_operator_account')
			->where('user_id', $user_id)
			->update($data);

		if($operator){
			return [
				'update' => true,
				'message' => 'Edit member successfully!'
			];
		}

		return [
			'error' => true,
			'update' => false,
			'message' => 'Edit member fail!'
		];
	}

	public function member_operator_method_delete($user_id)
	{	
		$get = $this->db_config
			->table('t_operator_account')
			->where('user_id', $user_id)
			->select('is_delete')
			->get()
			->getResult();

		$state = ($get[0]->is_delete) ? 0 : 1;

		$data = [
			'is_delete' => $state
		];

		$template = $this->db_config
			->table('t_operator_account')
			->where('user_id', $user_id)
			->update($data);

		if($template){
			return [
				'update' => true,
				'message' => ($state) ? 'Delete member successfully!' : 'Restore member successfully!'
			];
		}

		return [
			'error' => true,
			'update' => false,
			'message' => ($state) ? 'Delete member fail!' : 'Restore member fail!'
		];
	}

	public function member_operator_setting($user_id)
	{
		$setting = $this->db_config
			->table('t_user_setting')
			->where('user_id', $user_id)
			->countAllResults();

		$customer = $this->db_config
			->table('t_customer')
			->where('is_delete', 0)
			->get()
			->getResult();

		if(!$setting){

			foreach ($customer as $value) {
				$value->active = 0;
			}

			$data = [
				'user_id' => $user_id,
				'customer' => $customer,
				'setting' => array(
					'is_active' => 0, 
					'is_modify' => 0, 
					'is_delete' => 0, 
					'is_report' => 0, 
					'is_editor' => 0, 
					'is_chart' => 0, 
					'readonly' => 0, 
					'admin' => 0, 
					'super_admin' => 0
				)
			];

			return $data;

		}else{

			$get = $this->db_config
				->table('t_user_setting')
				->where('user_id', $user_id)
				->get()
				->getResult();

			$is_customer = json_decode($get[0]->is_customer, true);

			if($customer){
				foreach ($customer as $value) {
					foreach ($is_customer as $id) {
						if($value->customer_id === $id){
							$value->active = 1;
						}
					}
				}
			}

			$data = [
				'user_id' => $user_id,
				'customer' => $customer,
				'setting' => array(
					'is_active' => $get[0]->is_active, 
					'is_modify' => $get[0]->is_modify, 
					'is_delete' => $get[0]->is_delete, 
					'is_report' => $get[0]->is_report, 
					'is_editor' => $get[0]->is_editor, 
					'is_chart' => $get[0]->is_chart, 
					'readonly' => $get[0]->readonly, 
					'admin' => $get[0]->admin, 
					'super_admin' => $get[0]->super_admin
				)
			];

			return $data;

		}

		return false;
	}

	public function member_operator_method_setting_customer($user_id, $form)
	{
		$setting = $this->db_config
			->table('t_user_setting')
			->where('user_id', $user_id)
			->countAllResults();

		$is_customer = [];
		foreach ($form['data'] as $value) {
			array_push($is_customer, $value['customer_id']);
		}

		if(!$setting){

			$data = [
				'id' => uniqid(),
				'user_id' => $user_id,
				'is_customer' => json_encode($is_customer)
			];

			$result = $this->db_config
				->table('t_user_setting')
				->insert($data);

		}else{

			$data = [
				'is_customer' => json_encode($is_customer)
			];

			$result = $this->db_config
				->table('t_user_setting')
				->where('user_id', $user_id)
				->update($data);
		}

		if($result){
			return [
				'update' => true,
				'message' => 'Setting user successfully!'
			];
		}

		return [
			'error' => true,
			'update' => false,
			'message' => 'Setting user fail!'
		];
	}

	public function member_operator_method_setting_user($user_id, $form)
	{
		$setting = $this->db_config
			->table('t_user_setting')
			->where('user_id', $user_id)
			->countAllResults();

		$data = [
				'is_active' => $form['is_active'] || 0, 
				'is_modify' => $form['is_modify'] || 0, 
				'is_delete' => $form['is_delete'] || 0,
				'is_report' => $form['is_report'] || 0, 
				'is_editor' => $form['is_editor'] || 0, 
				'is_chart' => $form['is_chart'] || 0, 
				'readonly' => $form['readonly'] || 0, 
				'admin' => $form['admin'] || 0, 
				'super_admin' => $form['super_admin'] || 0
			];


		if(!$setting){

			$data['id'] = uniqid();
			$data['user_id'] = $user_id;
			$data['is_customer'] = '[]';

			$result = $this->db_config
				->table('t_user_setting')
				->insert($data);

		}else{

			$result = $this->db_config
				->table('t_user_setting')
				->where('user_id', $user_id)
				->update($data);
		}

		if($result){
			return [
				'update' => true,
				'message' => 'Setting user successfully!'
			];
		}

		return [
			'error' => true,
			'update' => false,
			'message' => 'Setting user fail!'
		];
	}


	//--------------------------------MENEAGE-----------------------------------------//


	public function manager_text_style()
	{
		$style = $this->db_config
			->table('t_text_style')
			->select('id, customer, style, font, formate, font_size, opacity, color, bound, bold, italic, underline, is_delete')
			->get()
			->getResult();

		return $style;
	}

	public function manager_text_style_edit($text_id)
	{
		$style = $this->db_config
			->table('t_text_style')
			->where('id', $text_id)
			->select('id, customer, style, font, formate, font_size, opacity, color, bound, bold, italic, underline, is_delete')
			->get()
			->getResult();

		return $style;
	}

	public function manager_text_style_method_edit($text_id, $form)
	{
		$data = [
			'customer' => $form['customer'],
			'style' => $form['style'],
			'font' => $form['font'],
			'formate' => $form['formate'],
			'font_size' => $form['font_size'],
			'opacity' => $form['opacity'],
			'color' => $form['color'],
			'bound' => $form['bound'],
			'bold' => $form['bold'],
			'italic' => $form['italic'],
			'underline' => $form['underline'],
		];

		$style = $this->db_config
			->table('t_text_style')
			->where('id', $text_id)
			->update($data);

		if($style){
			return [
				'update' => true,
				'message' => 'Edit text style successfully!'
			];
		}

		return [
			'error' => true,
			'update' => false,
			'message' => 'Edit text style fail!'
		];
	}

	public function manager_text_style_method_delete($text_id)
	{
		$get = $this->db_config
			->table('t_text_style')
			->where('id', $text_id)
			->select('is_delete')
			->get()
			->getResult();

		$state = ($get[0]->is_delete) ? 0 : 1;

		$data = [
			'is_delete' => $state
		];

		$template = $this->db_config
			->table('t_text_style')
			->where('id', $text_id)
			->update($data);

		if($template){
			return [
				'update' => true,
				'message' => ($state) ? 'Delete text style successfully!' : 'Restore font successfully!'
			];
		}

		return [
			'error' => true,
			'update' => false,
			'message' => ($state) ? 'Delete text style fail!' : 'Restore font fail!'
		];
	}
}
