<?php namespace App\Models;

use CodeIgniter\Model;

//use CodeIgniter\HTTP\RequestInterface;

class ModelLogin extends Model
{

	public $db;
	public $people;
	public $customer;
	public $date;
	//protected $primaryKey = 'id';
	//protected $returnType = 'array';

	public $request;

	public function __construct()
	{
		$this->db_config = \Config\Database::connect('default', false);
		$this->db_people = \Config\Database::connect('baezenic_people', false);

		$this->people = $this->db_people->table('t_people');
		$this->customer = $this->db_config->table('t_customer_account');
		$this->data = date("Y-m-d h:i:s");
	}

	public function get()
	{
		$query = $this->people
			->select()
			->get()
			->getResult();

		echo json_encode($query);
	}

	public function admin($user_id)
	{
		$query = $this->db_config
            ->table('t_user_setting')
	    	->where('user_id', $user_id)
			->select('admin, super_admin')
	   		->get()
			->getResult();

	   	if($query[0]->admin === '1' || $query[0]->super_admin === '1'){

	   		$data = [
	   			'status' => 0
	   		];

	   		$admin = $this->db_config
            	->table('t_user_setting')
	    		->where('user_id', $user_id)
	    		->select('admin, super_admin')
	    		->get()
				->getResult();

			if($admin[0]->admin){
				$data['status'] = 1;
			}

			if($admin[0]->super_admin){
				$data['status'] = 2;
			}

			return $data;
	   	}

	   	return false;
	}

	public function cek_login($email)
	{

		if($people = $this->people($email)){
			return $people;
		};

		if($customer = $this->customer($email)){
			return $customer;
		};

	}

	public function people($email){
		$query = $this->db_config
            ->table('t_operator_account')
	    	->where('email', $email)
	    	->orWhere('username', $email)
	    	->countAllResults();

	    if($query === 0){
	    	$query = $this->people
				->where('email', $email)
				->countAllResults();

			if($query > 0){
				$data = $this->people
					->where('email', $email)
	                ->limit(1)
	                ->get()
	                ->getRowArray();

	            $arr = [];
	            $arr['uid'] = $data['id'];
	            $arr['name'] = $data['Name'];
	            $arr['email'] = $data['Email'];
	            $arr['password'] = $this->isValidMd5($data['password']);
	            $arr['state'] = 'people';

	            $account = [
		    			'id' => uniqid(),
		    			'user_id' => $data['id'],
		    			'name' => $data['Name'],
		    			'username' => $data['Email'],
		    			'password' => $arr['password'],
		    			'email' => $data['Email'],
		    			'create_date' => $this->data,
		    			'update_date' => $this->data
		    		];

		    	$insert = $this->db_config
		    			->table('t_operator_account')
		    			->insert($account);

		    	if($insert){
		    		return $arr;
		    	}
	    	}

	    }else{
	    	$query = $this->db_config
	            ->table('t_operator_account')
		    	->where('email', $email)
		    	->orWhere('username', $email)
		    	->limit(1)
		        ->get()
		        ->getRowArray();

            $arr = [];
            $arr['uid'] = $query['user_id'];
            $arr['name'] = $query['name'];
            $arr['email'] = $query['email'];
            $arr['password'] = $this->isValidMd5($query['password']);
            $arr['state'] = 'people';

            return $arr;
	    }

	    return $arr = 0;
	}

	public function customer($email){
		$query = $this->customer
			->where('email', $email)
			->orWhere('username', $email)
			->countAllResults();

		if($query > 0){
			$data = $this->customer
				->where('email', $email)
				->orWhere('username', $email)
                ->limit(1)
                ->get()
                ->getRowArray();
                
            $arr = [];
            $arr['uid'] = $data['id'];
            $arr['name'] = $data['name'];
            $arr['email'] = $data['email'];
            $arr['password'] = $this->isValidMd5($data['password']);
            $arr['state'] = 'customer';
		}else{
			$arr = 0;
		}
		return $arr;
	}

	public function isValidMd5($md5 ='')
	{
    	$cek = preg_match('/^[a-f0-9]{32}$/', $md5);

    	if(!$cek){
    		return md5($md5);
    	}else{
    		return $md5;
    	}
	}
}